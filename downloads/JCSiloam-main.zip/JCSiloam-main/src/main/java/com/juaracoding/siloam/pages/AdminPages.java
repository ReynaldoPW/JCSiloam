package com.juaracoding.siloam.pages;

public class AdminPages {
}
