package com.juaracoding.siloam.drivers.strategies;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
    WebDriver setStrategy();

}
